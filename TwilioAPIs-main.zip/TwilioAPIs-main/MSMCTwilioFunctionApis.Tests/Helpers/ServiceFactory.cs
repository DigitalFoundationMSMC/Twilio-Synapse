﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using MSMCTwilioFunctionApis.Auth;
using MSMCTwilioFunctionApis.Business.Services;
using MSMCTwilioFunctionApis.Controllers;
using MSMCTwilioFunctionApis.Persistence.Factories;
using MSMCTwilioFunctionApis.Persistence.Helpers;
using MSMCTwilioFunctionApis.Persistence.Repositories;

namespace MSMCTwilioFunctionApis.Tests.Helpers
{
	public class ServiceFactory
	{
		private static readonly IConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
		private static readonly IConfiguration configuration;

		static ServiceFactory()
		{
			configurationBuilder.AddJsonFile("appsettings.json");
			configuration = configurationBuilder.Build();
		}

		public static DbService CrateDbService()
		{
			return new DbService(new SqlConnectionFactory(configuration));
		}

		public static TwilioFunctionsController CreateDatabasesController()
		{
			return new TwilioFunctionsController(CreateTwilioFunctionService());
		}

		public static TwilioFunctionService CreateTwilioFunctionService()
		{
			return new TwilioFunctionService(CreateTwilioFunctionRepository());
		}

		public static TwilioFunctionRepository CreateTwilioFunctionRepository()
		{
			//return new TwilioFunctionRepository(CrateDbService(), new AuthService(new HttpContextAccessor(), configuration));
			return new TwilioFunctionRepository(CrateDbService(), new AuthService());
		}
	}
}
