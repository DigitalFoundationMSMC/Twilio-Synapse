using MSMCTwilioFunctionApis.Common.DTO;
using MSMCTwilioFunctionApis.Controllers;
using MSMCTwilioFunctionApis.Tests.Helpers;
using System;
using System.Threading.Tasks;
using Xunit;

namespace MSMCTwilioFunctionApis.Tests
{
	public class TwilioFunctionsControllerTests
	{
		private readonly TwilioFunctionsController _functionsController;

		public TwilioFunctionsControllerTests()
		{
			_functionsController = ServiceFactory.CreateDatabasesController();
		}

		[Fact]
		public async Task GetAllMessages()
		{
			//await _functionsController.GetMessages();
		}

		[Fact]
		public async Task SaveFunctionParams_SavesRecord()
		{
			var createDto = CreateTwilioFunctionParamsDTO();
			var createResponse = await _functionsController.SaveFunctionParams(createDto);
			Assert.True(createResponse.Success);
			Assert.Empty(createResponse.Messages);
		}

		[Fact]
		public async Task GetAll_ReturnRecords()
		{
			var getAllResponse = await _functionsController.GetAll();
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
			Assert.NotEmpty(getAllResponse.Records);
		}

		[Fact]
		public async Task SendMessageUsingShortCode()
		{
			var dto = new SendShortCodeDTO
			{
				ToPhoneNumber = "+13052040686",
				FromPhoneNumber = "674674",
				//ToPhoneNumber = "+13058121653",
				Body = "Test body..",
				ExecutionId = "12345",
				FlowId = "123456",
				Language = "Spanish"
			};
			var getAllResponse = await _functionsController.SendMessage(dto);
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
		}

		[Fact]
		public async Task RespondToShortCode()
		{
			var dto = new SendShortCodeDTO
			{
				ToPhoneNumber = "+923135341994",
				PatientResponse = "cancel"
			};
			var getAllResponse = await _functionsController.RespondToShortCode(dto);
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
			Assert.NotNull(getAllResponse.Record);
		}

		[Fact]
		public async Task GetExecutionDetailsByPhoneNumber()
		{
			var dto = new PhoneNumberDTO
			{
				PhoneNumber = "+13052040686",
			};
			var getAllResponse = await _functionsController.GetExecutionDetailsByPhoneNumber(dto);
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
			Assert.NotNull(getAllResponse.Record);
		}

		[Fact]
		public async Task SaveTwilioResponse()
		{
			var dto = new TwilioResponseDTO
			{
				Body = "Twilio response body  ",
				PhoneNumber = "PhoneNumber"
			};
			var getAllResponse = await _functionsController.SaveTwilioResponse(dto);
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
		}

		[Fact]
		public async Task SavePatientSubscription()
		{
			var dto = new PatientSubscriptionDTO
			{
				PhoneNumber = "PhoneNumber1",
				SubscriptionType = 1
			};
			var getAllResponse = await _functionsController.SaveOrUpdatePatientSubscription(dto);
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
		}

		[Fact]
		public async Task SaveExecutionData()
		{
			//var dto = new ExecutionDTO
			//{
			//	Pid_16 = "pid_16",
			//	Time_5 = "time_5",
			//	Visit_7 = "visit_7",
			//	Flag_29 = "flag_29",
			//	Confirmed_24 = "confirmed_24",
			//	Lname_18 = "lname_18",
			//	Apptlength_6 = "apptlength_6",
			//	Csn_2 = "csn_2",
			//	Fname_19 = "fname_19",
			//	Depphone_27 = "depphone_27",
			//	Date_4 = "date_4",
			//	Multiple_12 = "multiple_12",
			//	Department_14 = "department_14",
			//	Preferred_20 = "preferred_20",
			//	Depid_26 = "depid_26",
			//	Provider_15 = "provider_15",
			//	Language_22 = "language_22",
			//	Commid_23 = "commid_23",
			//	Arrival = "arrival",
			//	Status_30 = "status_30",
			//	Cell_21 = "cell_21",
			//	Vid_25 = "vid_25",
			//	PatResponse = "patresponse",
			//	Daynum = "daynum",
			//	Filetype = "filetype",
			//	PhoneNumber = "+13052040686"
			//};
			var dto = new ExecutionDTO
			{
				Pid_16 = "Z1663669",
				Time_5 = "5:30 AM",
				Visit_7 = "PHP INITIAL ASSESSMENT",
				Dose_29 = "1",
				Confirmed_24 = "",
				Lname_18 = "Zzztest",
				DayOfWeek_6 = "60",
				Csn_2 = "5010417965",
				Fname_19 = "Epictwo",
				Depphone_27 = "305-674-2627",
				Date_4 = "2/20/2021",
				Multiple_12 = "1",
				Department_14 = "Mount Sinai Outpatient Behavioral Health Center Miami Beach",
				Preferred_20 = "",
				Depid_26 = "10111647",
				Provider_15 = "Php Clinician",
				Language_22 = "22",
				Commid_23 = "4011960",
				Arrival = "30",
				Status_30 = "Sch",
				Cell_21 = "3052833550",
				Vid_25 = "11700059",
				PatResponse = "confirm",
				Daynum = "3",
				Filetype = "HOD",
				PhoneNumber = "+13052833550",
			};
			var getAllResponse = await _functionsController.SaveExecutionData(dto);
			Assert.True(getAllResponse.Success);
			Assert.Empty(getAllResponse.Messages);
		}

		private TwilioFunctionParamsDTO CreateTwilioFunctionParamsDTO()
		{
			return new TwilioFunctionParamsDTO
			{
				Csn = "Csn1",
				Pid = "Pid1",
				Call = "Call1",
				Confirmed = "Confirmed1",
				Sms = "Sms1",
				Type = "Type1"
			};
		}
	}
}
