﻿namespace MSMCTwilioFunctionApis.Auth
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
