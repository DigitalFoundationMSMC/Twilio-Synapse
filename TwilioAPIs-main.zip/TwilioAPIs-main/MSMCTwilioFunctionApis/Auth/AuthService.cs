﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;

namespace MSMCTwilioFunctionApis.Auth
{
	public interface IAuthService
	{
		//public LoggedInUser LoggedInUser { get; }
		//public int GetLoggedInUserId();
	}

	public class AuthService : IAuthService
	{
		private readonly IHttpContextAccessor _httpContextAccessor;
		private readonly AppSettings _appSettings;
		private readonly string _secret;
	
		//public AuthService(IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
		public AuthService()
		{
			//_httpContextAccessor = httpContextAccessor;
			//var appSettings = configuration.GetSection("AppSettings");
			//_secret = appSettings.GetSection("Secret").Value;
		}

		//public LoggedInUser LoggedInUser
		//{
		//	get
		//	{
		//		var tempUser = new LoggedInUser { FirmId = 1 };
		//		return tempUser;
		//	}
		//}

		//public int GetLoggedInUserId()
		//{
		//	var token = _httpContextAccessor.HttpContext.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
		//	var tokenHandler = new JwtSecurityTokenHandler();
		//	var key = Encoding.ASCII.GetBytes(_secret);
		//	tokenHandler.ValidateToken(token, new TokenValidationParameters
		//	{
		//		ValidateIssuerSigningKey = true,
		//		IssuerSigningKey = new SymmetricSecurityKey(key),
		//		ValidateIssuer = false,
		//		ValidateAudience = false,
		//		ClockSkew = TimeSpan.Zero
		//	}, out SecurityToken validatedToken);

		//	var jwtToken = (JwtSecurityToken)validatedToken;
		//	return int.Parse(jwtToken.Claims.First(x => x.Type == "id").Value);
		//}
	}
}
