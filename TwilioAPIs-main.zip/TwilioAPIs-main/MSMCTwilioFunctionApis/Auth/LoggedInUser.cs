﻿using System;

namespace MSMCTwilioFunctionApis.Auth
{
	public class LoggedInUser
	{
		public int Id { get; set; }
		public int EmployeeId { get; set; }
		public Guid TenantId { get; set; }
		public int FirmId { get; set; }
		public int AdministrationId { get; set; }
	}
}
