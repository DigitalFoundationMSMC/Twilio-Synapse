﻿using MSMCTwilioFunctionApis.Common.DTO;
using MSMCTwilioFunctionApis.Persistence.Repositories;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MSMCTwilioFunctionApis.Business.Services
{
	public interface ITwilioFunctionService
	{
		Task SaveDummyResponsesToTwilio(string toPhoneNumber, string body, DateTime? dateSent, string direction);
		Task SaveFunctionParamsLost(string pid, string csn, string call, DateTime createdAt, string toPhoneNumber, string flowId, string executionId, string sid);
		Task SaveFunctionParams(TwilioFunctionParamsDTO dto);
		Task SaveFunctionParamsTST(TwilioFunctionParamsDTO dto);
		Task SaveShortCodeMessageDetails(SendShortCodeDTO dto);
		Task<SendShortCodeDTO> RespondToShortCode(SendShortCodeDTO dto);
		Task SaveExecutionData(ExecutionDTO dto);
		Task SaveTwilioResponse(TwilioResponseDTO dto);
		Task SaveOrUpdatePatientSubscription(PatientSubscriptionDTO dto);
		Task<IEnumerable<TwilioFunctionParamsDTO>> GetAll();
		Task<SendShortCodeDTO> GetExecutionDetailsByPhoneNumber(PhoneNumberDTO dto);
		Task<bool> IsValidUser(string userName, string password);
	}

	public class TwilioFunctionService : ITwilioFunctionService
	{
		private readonly ITwilioFunctionRepository _twilioFunctionRepository;

		public TwilioFunctionService(ITwilioFunctionRepository twilioFunctionRepository)
		{
			_twilioFunctionRepository = twilioFunctionRepository ?? throw new ArgumentNullException(nameof(twilioFunctionRepository));
		}

		public async Task SaveDummyResponsesToTwilio(string toPhoneNumber, string body, DateTime? dateSent, string direction)
		{
			await _twilioFunctionRepository.SaveDummyResponsesToTwilio(toPhoneNumber, body, dateSent, direction);
		}

		public async Task SaveFunctionParamsLost(string pid, string csn, string call, DateTime createdAt, string toPhoneNumber, string flowId,
			string executionId, string sid)
		{
			await _twilioFunctionRepository.SaveFunctionParamsLost(pid, csn, call, createdAt, toPhoneNumber, flowId, executionId, sid);
		}

		public async Task SaveFunctionParams(TwilioFunctionParamsDTO dto)
		{
			await _twilioFunctionRepository.SaveFunctionParams(dto);
		}

		public async Task SaveFunctionParamsTST(TwilioFunctionParamsDTO dto)
		{
			await _twilioFunctionRepository.SaveFunctionParamsTST(dto);
		}

		public async Task SaveShortCodeMessageDetails(SendShortCodeDTO dto)
		{
			await _twilioFunctionRepository.SaveShortCodeMessageDetails(dto);
		}

		public async Task<SendShortCodeDTO> RespondToShortCode(SendShortCodeDTO dto)
		{
			return await _twilioFunctionRepository.RespondToShortCode(dto);
		}

		public async Task SaveExecutionData(ExecutionDTO dto)
		{
			await _twilioFunctionRepository.SaveExecutionData(dto);
		}

		public async Task SaveTwilioResponse(TwilioResponseDTO dto)
		{
			await _twilioFunctionRepository.SaveTwilioResponse(dto);
		}

		public async Task SaveOrUpdatePatientSubscription(PatientSubscriptionDTO dto)
		{
			var isCreated = await _twilioFunctionRepository.IsPatientSubscriptionExist(dto.PhoneNumber);

			if(isCreated)
				await _twilioFunctionRepository.UpdatePatientSubscription(dto);
			else
				await _twilioFunctionRepository.SavePatientSubscription(dto);
		}

		public async Task<IEnumerable<TwilioFunctionParamsDTO>> GetAll()
		{
			return await _twilioFunctionRepository.GetAll();
		}

		public async Task<SendShortCodeDTO> GetExecutionDetailsByPhoneNumber(PhoneNumberDTO dto)
		{
			return await _twilioFunctionRepository.GetExecutionDetailsByPhoneNumber(dto.PhoneNumber);
		}

		public async Task<bool> IsValidUser(string userName, string password)
		{
			return await _twilioFunctionRepository.IsValidUser(userName, password);
		}
	}
}
