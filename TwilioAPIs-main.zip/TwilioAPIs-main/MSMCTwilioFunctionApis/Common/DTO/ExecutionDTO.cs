﻿namespace MSMCTwilioFunctionApis.Common.DTO
{
	public class ExecutionDTO
	{
		public string Pid_16 { get; set; }
		public string Time_5 { get; set; }
		public string Visit_7 { get; set; }
		public string Dose_29 { get; set; }
		public string Confirmed_24 { get; set; }
		public string Lname_18 { get; set; }
		public string DayOfWeek_6 { get; set; }
		public string Csn_2 { get; set; }
		public string Fname_19 { get; set; }
		public string Depphone_27 { get; set; }
		public string Date_4 { get; set; }
		public string Multiple_12 { get; set; }
		public string Department_14 { get; set; }
		public string Preferred_20 { get; set; }
		public string Depid_26 { get; set; }
		public string Provider_15 { get; set; }
		public string Language_22 { get; set; }
		public string Commid_23 { get; set; }
		public string Arrival { get; set; }
		public string Status_30 { get; set; }
		public string Cell_21 { get; set; }
		public string Vid_25 { get; set; }
		public string PatResponse { get; set; }
		public string Daynum { get; set; }
		public string Filetype { get; set; }
		public string PhoneNumber { get; set; }
	}
}
