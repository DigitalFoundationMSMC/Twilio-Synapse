﻿namespace MSMCTwilioFunctionApis.Common.DTO
{
	public class PhoneNumberDTO
	{
		public string PhoneNumber { get; set; }
	}
}
