﻿using System;

namespace MSMCTwilioFunctionApis.Common.DTO
{
	public class SendShortCodeDTO
	{
		public int Id { get; set; }
		public string ExecutionId { get; set; }
		public string FlowId { get; set; }
		public string ToPhoneNumber { get; set; }
		public string FromPhoneNumber { get; set; }
		public string PatientResponse { get; set; }
		public string Body { get; set; }
		public int HasResponded { get; set; }
		public bool IsDelivered { get; set; }
		public DateTime? CreatedAt { get; set; }
		public bool DontSaveToDatabase { get; set; }
		public string Language { get; set; }
	}
}
