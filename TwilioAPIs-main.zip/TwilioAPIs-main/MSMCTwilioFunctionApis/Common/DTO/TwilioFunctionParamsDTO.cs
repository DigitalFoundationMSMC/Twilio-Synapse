﻿namespace MSMCTwilioFunctionApis.Common.DTO
{
	public class TwilioFunctionParamsDTO
	{
		public int Id { get; set; }
		public string Csn { get; set; }
		public string Pid { get; set; }
		public string Call { get; set; }
		public string Confirmed { get; set; }
		public string Sms { get; set; }
		public string Type { get; set; }
		public bool IsCopied { get; set; }
	}
}
