﻿using System;

namespace MSMCTwilioFunctionApis.Common.DTO
{
	public class TwilioResponseDTO
	{
		public int Id { get; set; }
		public string Body { get; set; }
		public string PhoneNumber { get; set; }
		public DateTime CreatedAt { get; set; }
	}
}
