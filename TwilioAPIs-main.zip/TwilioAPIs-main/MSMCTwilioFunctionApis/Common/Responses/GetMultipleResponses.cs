﻿using System.Collections.Generic;

namespace MSMCTwilioFunctionApis.Common.Responses
{
    public class GetMultipleResponses<T> : ResponseBase
    {
        public IEnumerable<T> Records { get; set; }
    }
}
