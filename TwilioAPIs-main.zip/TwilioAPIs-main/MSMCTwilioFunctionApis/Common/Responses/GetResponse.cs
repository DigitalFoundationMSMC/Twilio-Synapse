﻿namespace MSMCTwilioFunctionApis.Common.Responses
{
    public class GetResponse<T> : ResponseBase
    {
        public T Record { get; set; }
    }
}
