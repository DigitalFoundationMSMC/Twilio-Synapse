﻿using System.Collections.Generic;

namespace MSMCTwilioFunctionApis.Common.Responses
{
    public class ResponseBase
    {
        public bool Success { get; set; }
        public List<string> Messages { get; set; }

        public ResponseBase()
        {
            Success = true;
            Messages = new List<string>();
        }
    }
}
