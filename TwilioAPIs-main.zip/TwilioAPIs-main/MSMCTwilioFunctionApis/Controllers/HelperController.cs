﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MSMCTwilioFunctionApis.Common.Responses;

namespace MSMCTwilioFunctionApis.Controllers
{
	public class HelperController : ControllerBase
	{
		protected async Task<TResult> Invoke<TResult>(Func<Task<TResult>> func)
			where TResult : ResponseBase, new()
		{
			TResult result = new TResult();
			try
			{
				result = await func();
			}
			catch (Exception de)
			{
				result.Success = false;
				result.Messages.Add(de.Message);
			}

			return result;
		}
	}
}