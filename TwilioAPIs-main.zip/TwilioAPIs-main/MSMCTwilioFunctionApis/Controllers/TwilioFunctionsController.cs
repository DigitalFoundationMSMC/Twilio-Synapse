﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MSMCTwilioFunctionApis.Business.Services;
using MSMCTwilioFunctionApis.Common.DTO;
using MSMCTwilioFunctionApis.Common.Responses;
using Newtonsoft.Json.Linq;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Rest.Studio.V1.Flow;
using Twilio.Rest.Studio.V1.Flow.Execution;

namespace MSMCTwilioFunctionApis.Controllers
{
	[Route("[controller]")]
	[ApiController]
	public class TwilioFunctionsController : HelperController
	{
		private readonly ITwilioFunctionService _twilioFunctionService;

		public TwilioFunctionsController(ITwilioFunctionService twilioFunctionService)
		{
			_twilioFunctionService = twilioFunctionService ?? throw new ArgumentNullException(nameof(twilioFunctionService));
		}

		//Saves patient confirmations
		[HttpPost("SaveFunctionParams")]
		public async Task<ResponseBase> SaveFunctionParams([FromForm] TwilioFunctionParamsDTO dto)
		{
			var result = new ResponseBase();
			if (await IsValidUser(HttpContext))
			{
				return await Invoke(async () =>
				{
					var result = new ResponseBase();
					await _twilioFunctionService.SaveFunctionParams(dto);
					return result;
				});
			}
			else
			{
				result.Success = false;
				result.Messages.Add("Incorrect user or password");
				return result;
			}
		}

		//Saves patient confirmations in a test table
		[HttpPost("SaveFunctionParamsTST")]
		public async Task<ResponseBase> SaveFunctionParamsTST([FromForm] TwilioFunctionParamsDTO dto)
		{
			var result = new ResponseBase();
			if (await IsValidUser(HttpContext))
			{
				return await Invoke(async () =>
				{
					await _twilioFunctionService.SaveFunctionParamsTST(dto);
					return result;
				});
			}
			else
			{
				result.Success = false;
				result.Messages.Add("Incorrect user or password");
				return result;
			}

		}

		//Sends a message using a short code which is in this case 674674
		[HttpPost("SendMessageUsingShortCode")]
		public async Task<GetResponse<SendShortCodeDTO>> SendMessageUsingShortCode([FromForm] SendShortCodeDTO dto)
		{
			return await SendMessage(dto, "674674", true);
		}

		[HttpPost("SendMessageUsingShortCodeTST")]
		public async Task<GetResponse<SendShortCodeDTO>> SendMessageUsingShortCodeTST([FromForm] SendShortCodeDTO dto)
		{
			return await SendMessage(dto, "674674", false);
		}

		//Sends a message using a number provided in the parameters, if none then it just uses the default short code
		[HttpPost("SendMessage")]
		public async Task<GetResponse<SendShortCodeDTO>> SendMessage([FromForm] SendShortCodeDTO dto)
		{
			var from = dto.FromPhoneNumber;

			if (string.IsNullOrEmpty(from) || string.IsNullOrWhiteSpace(from))
				from = "674674";

			return await SendMessage(dto, from, true);
		}

		//Gets execution details using phone number, then updating a flag to not responded to all the messages sent except the last one, the last one it updates the patient actual response and the flag to has responded
		[HttpPost("RespondToShortCode")]
		public async Task<GetResponse<SendShortCodeDTO>> RespondToShortCode([FromForm] SendShortCodeDTO dto)
		{

			return await Invoke(async () =>
			{
				var result = new GetResponse<SendShortCodeDTO>();
				result.Record = await _twilioFunctionService.RespondToShortCode(dto);
				return result;
			});
		}

		//Gets execution details using phone number
		[HttpPost("GetExecutionDetailsByPhoneNumber")]
		public async Task<GetResponse<SendShortCodeDTO>> GetExecutionDetailsByPhoneNumber([FromForm] PhoneNumberDTO dto)
		{
			return await Invoke(async () =>
			{
				var result = new GetResponse<SendShortCodeDTO>();
				result.Record = await _twilioFunctionService.GetExecutionDetailsByPhoneNumber(dto);
				return result;
			});
		}

		//Saves the detailed execution data to TwilioRequests table
		[HttpPost("SaveExecutionData")]
		public async Task<ResponseBase> SaveExecutionData([FromForm] ExecutionDTO dto)
		{
			return await Invoke(async () =>
			{
				var result = new ResponseBase();
				await _twilioFunctionService.SaveExecutionData(dto);
				return result;
			});
		}

		//Saves all messages received without any validations
		[HttpPost("SaveTwilioResponse")]
		public async Task<ResponseBase> SaveTwilioResponse([FromForm] TwilioResponseDTO dto)
		{

			return await Invoke(async () =>
			{
				var result = new ResponseBase();
				await _twilioFunctionService.SaveTwilioResponse(dto);
				return result;
			});
		}

		//Saves patient subscription state sub/unsub. If sub/unsub multiple times on the same day then only the latest is considered
		[HttpPost("SaveOrUpdatePatientSubscription")]
		public async Task<ResponseBase> SaveOrUpdatePatientSubscription([FromForm] PatientSubscriptionDTO dto)
		{

			return await Invoke(async () =>
			{
				var result = new ResponseBase();
				await _twilioFunctionService.SaveOrUpdatePatientSubscription(dto);
				return result;
			});
		}

		[HttpGet("GetAll")]
		public async Task<GetMultipleResponses<TwilioFunctionParamsDTO>> GetAll()
		{
			return await Invoke(async () =>
			{
				var result = new GetMultipleResponses<TwilioFunctionParamsDTO>();
				result.Records = await _twilioFunctionService.GetAll();
				return result;
			});
		}

		private async Task<bool> IsValidUser(HttpContext context)
		{
			string authHeader = context.Request.Headers["Authorization"];
			if (authHeader != null && authHeader.StartsWith("Basic"))
			{
				//Extract credentials
				string encodedUsernamePassword = authHeader.Substring("Basic ".Length).Trim();
				Encoding encoding = Encoding.GetEncoding("iso-8859-1");
				string usernamePassword = encoding.GetString(Convert.FromBase64String(encodedUsernamePassword));

				int seperatorIndex = usernamePassword.IndexOf(':');

				var username = usernamePassword.Substring(0, seperatorIndex);
				var password = usernamePassword.Substring(seperatorIndex + 1);

				var isValid = await _twilioFunctionService.IsValidUser(username, password);
				return isValid;
			}
			else
			{
				// no authorization header
				context.Response.StatusCode = 401; //Unauthorized
				return false;
			}
		}

		private async Task<GetResponse<SendShortCodeDTO>> SendMessage([FromForm] SendShortCodeDTO dto, string from, bool sendActualMessage)
		{
			return await Invoke(async () =>
			{
				var result = new GetResponse<SendShortCodeDTO>();
				const string accountSid = "AC3a52dbc41d27ed971f5e55517e71897c";
				const string authToken = "0e3d3ca8986aa4c3448a3a82e246cc7a";
				string sendersPhoneNumber = from;
				//string phoneNumber = "+13058121653";
				string phoneNumber = dto.ToPhoneNumber;
				MessageResource twilioResponse = null;
				bool isSent = true;

				try
				{
					TwilioClient.Init(accountSid, authToken);

					if (sendActualMessage)
						twilioResponse = await MessageResource.CreateAsync(
									body: dto.Body,
									from: new Twilio.Types.PhoneNumber(sendersPhoneNumber),
									to: new Twilio.Types.PhoneNumber(phoneNumber)
								);
				}
				catch (Exception ex)
				{
					result.Success = false;
					isSent = false;
					result.Messages.Add(ex.Message);
				}

				if (sendActualMessage)
				{
					if (dto.HasResponded == 0 && isSent == true)
						dto.IsDelivered = IsDelivered(twilioResponse);
					else if (dto.HasResponded == 0 && isSent == false)
						dto.IsDelivered = false;
					else
						dto.IsDelivered = true;
				}
				else
					dto.IsDelivered = true;

				if (!dto.DontSaveToDatabase)
					await _twilioFunctionService.SaveShortCodeMessageDetails(dto);

				result.Record = dto;

				return result;
			});
		}

		private bool IsDelivered(MessageResource messageResponse)
		{
			var status = messageResponse.Status.ToString().ToLower();
			var isDelivered = true;
			var counter = 0;
			var statusRetreived = false;

			if (status == "accepted" || status == "queued")
			{
				while (counter < 10 && !statusRetreived)
				{
					Thread.Sleep(1000);
					//var message = MessageResource.Fetch(pathSid: "SM648b676f8fdf4b2596a2a44778ba1e8e");
					//var message = MessageResource.Fetch(pathSid: "SC9af9843767ee3b38e41ac9fc6a6ca3ad");
					var message = MessageResource.Fetch(pathSid: messageResponse.Sid);
					status = message.Status.ToString().ToLower();

					if (status == "failed" || status == "delivered" || status == "undelivered")
						statusRetreived = true;

					counter++;
				}
			}

			if (status != "delivered")
				isDelivered = false;

			return isDelivered;
		}

		private async Task GetMessages()
		{
			const string accountSid = "AC3a52dbc41d27ed971f5e55517e71897c";
			const string authToken = "0e3d3ca8986aa4c3448a3a82e246cc7a";

			try
			{
				TwilioClient.Init(accountSid, authToken);
				//Below is the code to get confirmation messages i.e Inbound messages
				/*var messages = await MessageResource.ReadAsync(pathAccountSid: accountSid, to: new Twilio.Types.PhoneNumber("674674"), dateSent: new DateTime(2023, 8, 17));
				var messagesList = messages.ToList();

				foreach (var li in messagesList)
				{
					var toPhoneNumber = li.From.ToString();
					var body = li.Body;
					var direction = li.Direction.ToString();
					var dateSent = li.DateSent;
					await _twilioFunctionService.SaveDummyResponsesToTwilio(toPhoneNumber, body, dateSent, direction);
				}

				messages = await MessageResource.ReadAsync(pathAccountSid: accountSid, to: new Twilio.Types.PhoneNumber("674674"), dateSent: new DateTime(2022, 5, 24));
				messagesList = messages.ToList();

				foreach (var li in messagesList)
				{
					var toPhoneNumber = li.From.ToString();
					var body = li.Body;
					var direction = li.Direction.ToString();
					var dateSent = li.DateSent;
					await _twilioFunctionService.SaveDummyResponsesToTwilio(toPhoneNumber, body, dateSent, direction);
				}*/

				//Below is the code to get reminders being sent against the flow ids mentioned below and then the execution ids against each one
				var flowId = "FW051bb752d192bf717921eeac9530ae9f";
				//var flowId = "FW209a70606e7c36e53cd70e25c901e6be";
				//var flowId = "FW9666ecb55d42fe121edeb46685394ea5";
				var executions = ExecutionResource.Read(
								dateCreatedFrom: new DateTime(2023, 8, 17, 0, 0, 0),
								dateCreatedTo: new DateTime(2023, 8, 19, 20, 59, 59),
								pathFlowSid: flowId);

				var executionList = executions.ToList();
				//var phoneNumbers = "+12012143796, +12012189892, +12012836887, +12013703260, +12014033191, +12014060365, +12014061943, +12014244788, +12015196426, +12015776282, +12016747654, +12016966237, +12017092778, +12017413496, +12017453980, +12019142800, +12019375155, +12023404393, +12024150560, +12024417920, +12025495084, +12026078943, +12038324954, +12066500003, +12074741469, +12076712693, +12077123325, +12125358669, +12127294025, +12129796969, +12154990266, +12158961711, +12165433790, +12178014312, +12244105833, +12392444726, +12396778246, +12398783831, +12487055557, +12487975300, +12489339359, +12517515090, +12529037430, +12533770944, +12673461414, +12679847099, +12819232221, +13014674741, +13016027049, +13018326256, +13025302511, +13038754425, +13052006596, +13052007552, +13052021608, +13052023231, +13052023619, +13052039963, +13052050111, +13052050155, +13052055528, +13052061580, +13052064440, +13052064800, +13052067827, +13052068260, +13052152904, +13052153694, +13052156795, +13052167160, +13052185846, +13052186056, +13052194644, +13052243244, +13052400066, +13052400495, +13052444047, +13052447281, +13052620106, +13052827989, +13052832926, +13052833168, +13052973747, +13052977877, +13052978599, +13052979062, +13052981956, +13052983581, +13052987745, +13052992430, +13052996713, +13052999956, +13053000977, +13053007290, +13053008141, +13053009812, +13053012222, +13053015354, +13053015533, +13053020919, +13053021148, +13053027448, +13053029583, +13053041712, +13053043232, +13053051503, +13053053789, +13053080856, +13053083008, +13053083838, +13053088233, +13053089119, +13053103126, +13053103380, +13053104818, +13053109643, +13053167368, +13053167371, +13053182510, +13053186445, +13053187442, +13053188505, +13053188988, +13053190756, +13053211077, +13053214006, +13053214391, +13053215594, +13053218254, +13053221945, +13053229350, +13053234556, +13053235629, +13053237424, +13053263401, +13053317483, +13053319525, +13053320251, +13053320274, +13053320491, +13053322101, +13053324169, +13053325911, +13053328250, +13053330930, +13053332287, +13053335049, +13053335174, +13053338467, +13053339360, +13053351367, +13053353999, +13053359403, +13053359693, +13053364299, +13053364631, +13053365657, +13053384960, +13053386059, +13053389229, +13053422175, +13053422822, +13053423024, +13053426379, +13053430300, +13053432451, +13053546045, +13053602869, +13053890051, +13053896799, +13053899042, +13053899638, +13053950999, +13053977491, +13054011821, +13054070251, +13054070469, +13054093233, +13054098555, +13054098720, +13054171372, +13054311399, +13054311430, +13054317592, +13054391283, +13054391590, +13054394096, +13054394147, +13054394480, +13054394797, +13054396107, +13054396868, +13054398351, +13054488649, +13054500261, +13054501551, +13054502406, +13054502745, +13054505986, +13054509061, +13054579803, +13054584610, +13054584923, +13054589954, +13054673925, +13054679432, +13054693967, +13054798203, +13054810232, +13054817557, +13054871337, +13054873480, +13054902096, +13054907008, +13054909022, +13054909269, +13054909443, +13054914066, +13054917048, +13054918570, +13054922505, +13054925362, +13054941794, +13054950402, +13054952129, +13054952344, +13054955558, +13054964259, +13054968374, +13054983396, +13054983476, +13054986143, +13054988110, +13055023291, +13055028347, +13055028624, +13055029694, +13055051224, +13055054805, +13055058918, +13055105150, +13055108280, +13055190264, +13055193050, +13055194776, +13055195227, +13055197445, +13055229089, +13055250184, +13055257138, +13055258911, +13055271964, +13055277814, +13055281781, +13055283555, +13055340038, +13055348253, +13055378144, +13055398838, +13055421191, +13055424188, +13055426270, +13055426435, +13055428753, +13055429210, +13055462787, +13055463177, +13055465028, +13055623008, +13055624726, +13055625659, +13055718255, +13055824799, +13055826448, +13055827862, +13055829176, +13055829333, +13055860901, +13055862026, +13055863537, +13055863884, +13055865218, +13055866291, +13055866654, +13055866932, +13055869000, +13055885227, +13055885461, +13055885465, +13055885525, +13055888414, +13055888910, +13056064313, +13056067261, +13056069492, +13056069579, +13056073120, +13056073176, +13056074864, +13056075770, +13056076660, +13056086345, +13056090570, +13056093653, +13056098905, +13056099218, +13056104107, +13056104122, +13056106197, +13056109092, +13056132584, +13056133008, +13056134565, +13056136523, +13056136642, +13056137346, +13056139422, +13056159001, +13056321427, +13056323151, +13056325573, +13056329069, +13056329573, +13056733464, +13056846982, +13056849376, +13056999178, +13057101592, +13057102208, +13057104111, +13057107070, +13057108683, +13057178573, +13057200254, +13057203414, +13057206937, +13057207991, +13057209340, +13057209897, +13057217311, +13057217444, +13057245655, +13057249065, +13057250549, +13057255670, +13057257457, +13057259508, +13057264291, +13057264462, +13057289485, +13057315538, +13057316313, +13057318341, +13057330655, +13057331084, +13057331945, +13057335115, +13057338635, +13057339782, +13057415516, +13057423377, +13057424874, +13057427082, +13057446918, +13057468828, +13057470208, +13057470916, +13057481632, +13057535514, +13057576773, +13057611318, +13057612300, +13057612810, +13057614175, +13057616666, +13057616883, +13057622618, +13057636778, +13057663273, +13057666820, +13057690683, +13057722914, +13057722937, +13057727366, +13057728802, +13057737100, +13057750602, +13057752705, +13057753207, +13057754331, +13057755779, +13057761359, +13057764838, +13057767528, +13057784189, +13057784621, +13057786042, +13057788787, +13057810776, +13057812093, +13057851979, +13057880484, +13057881657, +13057883449, +13057883982, +13057884848, +13057902767, +13057904815, +13057905657, +13057905919, +13057934069, +13057934310, +13057934325, +13057934673, +13057934965, +13057935027, +13057935275, +13057941743, +13057941755, +13057942350, +13057944788, +13057945782, +13057948854, +13057963173, +13057964279, +13057967165, +13057981143, +13057981444, +13057982014, +13057985473, +13057986433, +13057989386, +13057993981, +13057995458, +13057995939, +13057997123, +13058037049, +13058037278, +13058045205, +13058074410, +13058124363, +13058128881, +13058152960, +13058155814, +13058156747, +13058193268, +13058258127, +13058336794, +13058339959, +13058346173, +13058421071, +13058491142, +13058491823, +13058500067, +13058501946, +13058502619, +13058536220, +13058547418, +13058610325, +13058645647, +13058647728, +13058710024, +13058776595, +13058781882, +13058785262, +13058786516, +13058797001, +13058903113, +13058907979, +13058969889, +13058981767, +13058987255, +13059007294, +13059030614, +13059036700, +13059037550, +13059038735, +13059040382, +13059042430, +13059046015, +13059048885, +13059056377, +13059060769, +13059095329, +13059101564, +13059101952, +13059151878, +13059152875, +13059154573, +13059157124, +13059157316, +13059220629, +13059234927, +13059235451, +13059235527, +13059236024, +13059242504, +13059243123, +13059246640, +13059260373, +13059261165, +13059265270, +13059266727, +13059276811, +13059321023, +13059323479, +13059340505, +13059341260, +13059348867, +13059429063, +13059429183, +13059511477, +13059515056, +13059518094, +13059626748, +13059627878, +13059629391, +13059651482, +13059651501, +13059651589, +13059653325, +13059654277, +13059674549, +13059681510, +13059683215, +13059687254, +13059722016, +13059723434, +13059727742, +13059751144, +13059751219, +13059758743, +13059780909, +13059781096, +13059784414, +13059786646, +13059796237, +13059796347, +13059799536, +13059841269, +13059845606, +13059866919, +13059870142, +13059872703, +13059874055, +13059891109, +13059892783, +13059921438, +13059925698, +13059927163, +13059938605, +13059989552, +13106008797, +13122139770, +13123205454, +13123206484, +13125132555, +13125900390, +13125936969, +13214602567, +13219486796, +13473306903, +13474054439, +13474326758, +13474632590, +13474979671, +13477218266, +13478491652, +13479079247, +13866790702, +14015722407, +14017421636, +14042878877, +14048032134, +14048841199, +14049157695, +14065996216, +14073003028, +14074620268, +14077447463, +14083949637, +14085933435, +14102159077, +14106104976, +14108008569, +14124176851, +14127268084, +14132424558, +14135224150, +14155280171, +14155315034, +14155954392, +14157938683, +14247039932, +14408656621, +14436230004, +14436951368, +14707251073, +14752165563, +14803191840, +15025921559, +15037093433, +15042288723, +15082698565, +15084143272, +15104957257, +15162388814, +15163199845, +15164598685, +15166802352, +15168845357, +15169675002, +15169875396, +15182815834, +15187039595, +15203131941, +15305757532, +15512689697, +15516557939, +15613399181, +15613855804, +15614798424, +15615425674, +15615430516, +15615681538, +15615739319, +15616855596, +15617037435, +15618607716, +15618714918, +15712943868, +15852615810, +15854901615, +16035405427, +16037595078, +16054849001, +16068751039, +16077592948, +16093461528, +16106134609, +16106364222, +16122038011, +16122395614, +16143700507, +16156131289, +16169017341, +16172124677, +16176508707, +16178183323, +16178991694, +16179704150, +16306360810, +16315650032, +16319261813, +16462511297, +16462579147, +16463129168, +16464983688, +16465416719, +16466411349, +16469233962, +16502835392, +16503880995, +16514600756, +16515007110, +16787049970, +16787632297, +16788491956, +17034072048, +17039634444, +17049650140, +17067183657, +17132034254, +17132131140, +17139276462, +17142134398, +17145948203, +17158921228, +17192358495, +17192383031, +17203316104, +17322598200, +17324947915, +17328872814, +17542100731, +17542147894, +17542170918, +17542178958, +17542358067, +17542430005, +17542445757, +17542491477, +17706686794, +17723416657, +17724184417, +17726315588, +17729711112, +17734078687, +17862002346, +17862014770, +17862014830, +17862021524, +17862024572, +17862056015, +17862081029, +17862081562, +17862087701, +17862131396, +17862132783, +17862135614, +17862137703, +17862227982, +17862231552, +17862235176, +17862236469, +17862266503, +17862273433, +17862279896, +17862293980, +17862295522, +17862341773, +17862386787, +17862391608, +17862399441, +17862476380, +17862479817, +17862512911, +17862524354, +17862539574, +17862562275, +17862566052, +17862618922, +17862619572, +17862620510, +17862623831, +17862638651, +17862660240, +17862673408, +17862675106, +17862678363, +17862710351, +17862714896, +17862749852, +17862773543, +17862776694, +17862803915, +17862820013, +17862820202, +17862820289, +17862823798, +17862850076, +17862857529, +17862862523, +17862876177, +17862910777, +17862913003, +17862959695, +17862990091, +17862993174, +17862996854, +17863002049, +17863005520, +17863011642, +17863027581, +17863027898, +17863028678, +17863031924, +17863036766, +17863037555, +17863062967, +17863063067, +17863070394, +17863076217, +17863086221, +17863109394, +17863109833, +17863143921, +17863171537, +17863174457, +17863177987, +17863201637, +17863250309, +17863250654, +17863268505, +17863271887, +17863333638, +17863373055, +17863375160, +17863391051, +17863400692, +17863423710, +17863431697, +17863443797, +17863469508, +17863481462, +17863484140, +17863489396, +17863505619, +17863521587, +17863543784, +17863547460, +17863547584, +17863550273, +17863551385, +17863553925, +17863565479, +17863569929, +17863569955, +17863575161, +17863651438, +17863661205, +17863708332, +17863725163, +17863766063, +17863809342, +17863838403, +17863840476, +17863852451, +17863858920, +17863859665, +17863903870, +17863905504, +17863907041, +17863950220, +17863956957, +17864038789, +17864039084, +17864063536, +17864065602, +17864121618, +17864134066, +17864134764, +17864178436, +17864197777, +17864208523, +17864232700, +17864234785, +17864239294, +17864262117, +17864264555, +17864275944, +17864386896, +17864386989, +17864395779, +17864399263, +17864420594, +17864428592, +17864439272, +17864440395, +17864442727, +17864475781, +17864478931, +17864512288, +17864546356, +17864570808, +17864575255, +17864578764, +17864597570, +17864613712, +17864619374, +17864684349, +17864689097, +17864700415, +17864734585, +17864737348, +17864772873, +17864795366, +17864866009, +17864873321, +17864877775, +17864885246, +17864886646, +17864911722, +17864929938, +17864956203, +17865020224, +17865060805, +17865061177, +17865064510, +17865079372, +17865089376, +17865102915, +17865104959, +17865124784, +17865128850, +17865142798, +17865145531, +17865153413, +17865160659, +17865160945, +17865167390, +17865167836, +17865201950, +17865210797, +17865232963, +17865253874, +17865254449, +17865256972, +17865368499, +17865376067, +17865389348, +17865398367, +17865437226, +17865438234, +17865462259, +17865465336, +17865476704, +17865534463, +17865537117, +17865538757, +17865560253, +17865565263, +17865567884, +17865601526, +17865602964, +17865617053, +17865635389, +17865645641, +17865646682, +17865648616, +17865670467, +17865672140, +17865680346, +17865860285, +17865865970, +17865870456, +17865875082, +17865875510, +17865970432, +17865970611, +17865974536, +17866064693, +17866132930, +17866167985, +17866172934, +17866175926, +17866177966, +17866197216, +17866223722, +17866228930, +17866278491, +17866414267, +17866428205, +17866435636, +17866438255, +17866476941, +17866549699, +17866553470, +17866570078, +17866578201, +17866593691, +17866594299, +17866596518, +17866616014, +17866630438, +17866818193, +17866823590, +17866905034, +17866933283, +17867097124, +17867150137, +17867152215, +17867160445, +17867409794, +17867541448, +17867599094, +17867602491, +17867634775, +17867681950, +17867683326, +17867688824, +17867692855, +17867778907, +17867782982, +17867783160, +17867803170, +17867815587, +17867922636, +17867959356, +17867974355, +17867978380, +17867991080, +17867993228, +17868036625, +17868040889, +17868060772, +17868101457, +17868126881, +17868173517, +17868185719, +17868188618, +17868229992, +17868251954, +17868300008, +17868323190, +17868374456, +17868386184, +17868532566, +17868533623, +17868535339, +17868561782, +17868598014, +17868635794, +17868636352, +17868777069, +17868971422, +17868996488, +17868999384, +17869019832, +17869064251, +17869094966, +17869096041, +17869098365, +17869150684, +17869164832, +17869167317, +17869227399, +17869255349, +17869301517, +17869420790, +17869420940, +17869423965, +17869555670, +17869617449, +17869703707, +17869707642, +17869731071, +17869735265, +17869739289, +17869759573, +17869856921, +17869914442, +17869917824, +17869993853, +18082143828, +18172356666, +18178452615, +18186252248, +18322084062, +18325355663, +18452167744, +18453044717, +18455905202, +18455981955, +18474006355, +18474012736, +18479105377, +18505591348, +18572109432, +18573167261, +18599137417, +18607782467, +18632235413, +18638002042, +18653843393, +18656170917, +19012126106, +19034400013, +19043120192, +19082444901, +19083131570, +19083806475, +19084032140, +19084166798, +19086352921, +19088214141, +19099794053, +19143252164, +19144194134, +19145235623, +19145842078, +19145890301, +19146488364, +19147140314, +19163169779, +19172142114, +19172323072, +19172462022, +19173021149, +19173281454, +19173594739, +19174141837, +19175337821, +19175358449, +19175388864, +19175435999, +19175751699, +19175761122, +19175820304, +19176096989, +19176130011, +19176535313, +19176621515, +19176676657, +19176734981, +19176910838, +19177010137, +19177410718, +19177446739, +19177745400, +19178375522, +19178538082, +19178543772, +19178604874, +19178634191, +19179326290, +19179414946, +19179699216, +19179755103, +19292588424, +19294714441, +19412646420, +19542438405, +19542457153, +19542495681, +19542532830, +19542750611, +19542887276, +19542900140, +19542928562, +19542952111, +19542965749, +19542990260, +19543042946, +19543051098, +19543099726, +19543199807, +19543262624, +19543287377, +19543762561, +19544010554, +19544224848, +19544455374, +19544789281, +19544791211, +19544836380, +19544943966, +19544951598, +19544963305, +19545342500, +19545477142, +19545587729, +19545791908, +19545919009, +19545925307, +19545993944, +19546106560, +19546106798, +19546218833, +19546274055, +19546295609, +19546321121, +19546632366, +19546680559, +19546766447, +19546838350, +19546960416, +19547705952, +19547904124, +19548013041, +19548022643, +19548022645, +19548032382, +19548034177, +19548043939, +19548047440, +19548161210, +19548175293, +19548215442, +19548294172, +19548390296, +19548542621, +19548641903, +19548648975, +19548736009, +19548738288, +19548828149, +19549077337, +19549203000, +19549372872, +19707291429, +19736326306, +19802634754, +19898599124";
				//var phoneNumberList = phoneNumbers.Split(",").ToDictionary(key => key, value => value);
				var counterList = 0;
				var executionDtos = new List<ExecutionDTO>();

				foreach (var li in executionList)
				{
					counterList++;
					var executionId = li.Sid;
					var executionContext = ExecutionContextResource.Fetch(
											pathFlowSid: flowId,
											pathExecutionSid: li.Sid);
					var context = executionContext.Context.ToString();
					var jsonResponse = JObject.Parse(context);
					var flow = jsonResponse["flow"];
					var child = flow.Children();

					var counter = 0;
					var numberOfExecutions = 0;

					foreach (var ch in child)
					{
						if (counter == 1)
						{
							var data = ch.First;
							var pid_16 = data["pid_16"].ToString().Trim();
							var csn_2 = data["csn_2"].ToString().Trim();
							var createdAt = (DateTime)li.DateCreated;
							var toPhoneNumber = li.ContactChannelAddress.Trim();
							var Commid_23 = data["commid_23"].ToString().Trim();

							var sid = flow["sid"].ToString().Trim();
							//TODO:Undo this
							//await _twilioFunctionService.SaveFunctionParamsLost(pid_16, csn_2, Commid_23, createdAt, toPhoneNumber, flowId, executionId, sid);

							var Time_5 = data["time_5"].ToString().Trim();
							var Visit_7 = data["visit_7"].ToString().Trim();
							var Dose_29 = data["dose_29"].ToString().Trim();
							var Confirmed_24 = data["confirmed_24"].ToString().Trim();
							var Lname_18 = data["lname_18"].ToString().Trim();
							var DayOfWeek_6 = data["dayofweek_6"].ToString().Trim();
							var Fname_19 = data["fname_19"].ToString().Trim();
							var Depphone_27 = data["depphone_27"].ToString().Trim();
							var Date_4 = data["date_4"].ToString().Trim();
							var Multiple_12 = data["multiple_12"].ToString().Trim();
							var Department_14 = data["department_14"].ToString().Trim();
							var Preferred_20 = data["preferred_20"].ToString().Trim();
							var Depid_26 = data["depid_26"].ToString().Trim();
							var Provider_15 = data["provider_15"].ToString().Trim();
							var Language_22 = data["language_22"].ToString().Trim();

							var Arrival = data["arrival"].ToString().Trim();
							var Status_30 = data["status_30"].ToString().Trim();
							var Cell_21 = data["cell_21"].ToString().Trim();
							var Vid_25 = data["vid_25"].ToString().Trim();
							var PatResponseToken = data["patResponse"];
							var PatResponse = "";

							if (PatResponseToken != null)
								PatResponse = PatResponseToken.ToString().Trim();

							var Daynum = data["daynum"].ToString().Trim();
							var Filetype = data["filetype"].ToString().Trim();
							var PhoneNumber = "+1" + Cell_21;

							ExecutionDTO dto = new ExecutionDTO
							{
								Pid_16 = pid_16,
								Time_5 = Time_5,
								Visit_7 = Visit_7,
								Dose_29 = Dose_29,
								Confirmed_24 = Confirmed_24,
								Lname_18 = Lname_18,
								DayOfWeek_6 = DayOfWeek_6,
								Csn_2 = csn_2,
								Fname_19 = Fname_19,
								Depphone_27 = Depphone_27,
								Date_4 = Date_4,
								Multiple_12 = Multiple_12,
								Department_14 = Department_14,
								Preferred_20 = Preferred_20,
								Depid_26 = Depid_26,
								Provider_15 = Provider_15,
								Language_22 = Language_22,
								Commid_23 = Commid_23,
								Arrival = Arrival,
								Status_30 = Status_30,
								Cell_21 = Cell_21,
								Vid_25 = Vid_25,
								PatResponse = PatResponse,
								Daynum = Daynum,
								Filetype = Filetype,
								PhoneNumber = PhoneNumber,
							};

							executionDtos.Add(dto);
							await _twilioFunctionService.SaveExecutionData(dto);
						}

						numberOfExecutions++;
						counter++;
					}
				}

				var todayExecutions = executionDtos.Where(x => DateTime.Parse(x.Date_4).Day == 22);
			}
			catch (Exception ex)
			{
			}
		}

	}
}