﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace MSMCTwilioFunctionApis.Persistence.Factories
{
	public interface ISqlConnectionFactory
	{
		Task<SqlConnection> CreateConnection();
		Task<string> GetConnectionString(Guid tenantId = new Guid());
		Task<SqlConnection> CreateConnectionTST();
		Task<string> GetConnectionStringTST(Guid tenantId = new Guid());
	}
}
