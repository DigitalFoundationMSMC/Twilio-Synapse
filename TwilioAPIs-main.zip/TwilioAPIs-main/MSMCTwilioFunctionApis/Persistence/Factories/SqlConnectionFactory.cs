﻿using Microsoft.Extensions.Configuration;
using System;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace MSMCTwilioFunctionApis.Persistence.Factories
{
	public class SqlConnectionFactory : ISqlConnectionFactory
	{
		private readonly IConfiguration _configuration;

		public SqlConnectionFactory(IConfiguration configuration)
		{
			_configuration = configuration;
		}

		public async Task<SqlConnection> CreateConnection()
		{
			var connectionString = await GetConnectionString();
			return new SqlConnection(connectionString);
		}

		public Task<string> GetConnectionString(Guid tenantId = new Guid())
		{
			//var connectionString = ConfigurationManager.ConnectionStrings["Ruby"].ConnectionString;
			var connectionString = _configuration.GetConnectionString("dbConnect");
			return Task.FromResult(connectionString);
		}

		public async Task<SqlConnection> CreateConnectionTST()
		{
			var connectionString = await GetConnectionString();
			return new SqlConnection(connectionString);
		}

		public Task<string> GetConnectionStringTST(Guid tenantId = default)
		{
			var connectionString = _configuration.GetConnectionString("dbConnect");
			return Task.FromResult(connectionString);
		}
	}
}
