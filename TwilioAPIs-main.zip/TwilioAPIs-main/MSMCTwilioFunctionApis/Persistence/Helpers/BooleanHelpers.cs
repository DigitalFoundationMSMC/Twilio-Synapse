﻿using System;

namespace MSMCTwilioFunctionApis.Persistence.Helpers
{
	public static class BooleanHelpers
	{
		public static bool? ParseFromDatabase(object input)
		{
			return input is DBNull ? null : (bool?)Convert.ToBoolean(input);
		}

		public static object StoreNullableInDatabase(bool? input)
		{
			return input.HasValue ? (object)input.Value : DBNull.Value;
		}
	}
}
