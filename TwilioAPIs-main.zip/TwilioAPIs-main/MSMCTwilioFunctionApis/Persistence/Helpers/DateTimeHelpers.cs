﻿using System;

namespace MSMCTwilioFunctionApis.Persistence.Helpers
{
	public static class DateTimeHelpers
	{
		public static DateTime? ParseFromDatabase(object input)
		{
			return input is DBNull ? null : (DateTime?)(input);
		}

		public static object StoreNullableInDatabase(DateTime? input)
		{
			return input.HasValue ? (object)input.Value : DBNull.Value;
		}
	}
}
