﻿using MSMCTwilioFunctionApis.Persistence.Factories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MSMCTwilioFunctionApis.Persistence.Helpers
{
	public interface IDbService
	{
		Task<TResult> Query<TResult>(CommandType commandType, string query, IEnumerable<SqlParameter> parameters,
													Func<SqlDataReader, TResult> resultProcessor);
		Task Execute(CommandType commandType, string query, IEnumerable<SqlParameter> parameters);
		Task ExecuteTST(CommandType commandType, string query, IEnumerable<SqlParameter> parameters);
	}

	public class DbService : IDbService
	{
		private readonly ISqlConnectionFactory _sqlConnectionFactory;

		public DbService(ISqlConnectionFactory sqlConnectionFactory)
		{
			_sqlConnectionFactory = sqlConnectionFactory ?? throw new ArgumentNullException(nameof(sqlConnectionFactory));
		}

		public async Task<TResult> Query<TResult>(CommandType commandType, string query, IEnumerable<SqlParameter> parameters,
													Func<SqlDataReader, TResult> resultProcessor)
		{
			SetEmptyOrNullParametersToDBNull(parameters);
			//DebugLog(query, parameters);

			TResult result = default(TResult);
			using (var conn = await _sqlConnectionFactory.CreateConnection())
			{
				using (var cmd = new SqlCommand(query, conn))
				{
					cmd.CommandType = commandType;
					cmd.CommandTimeout = 1200;
					cmd.Parameters.AddRange(parameters.ToArray());
					await conn.OpenAsync();
					//try
					//{
						using (SqlDataReader dr = await cmd.ExecuteReaderAsync())
						{
							result = resultProcessor(dr);
						}
					//}
					//catch (SqlException se)
					//{
					//	throw new Exception(se.Message);
					//	//HandleException(se, query, parameters);
					//}

				}
			}
			return result;
		}

		public async Task Execute(CommandType commandType, string query, IEnumerable<SqlParameter> parameters)
		{
			await ExecuteQuery(commandType, query, parameters, _sqlConnectionFactory.CreateConnection);
		}

		public async Task ExecuteTST(CommandType commandType, string query, IEnumerable<SqlParameter> parameters)
		{
			await ExecuteQuery(commandType, query, parameters, _sqlConnectionFactory.CreateConnectionTST);
		}

		private async Task ExecuteQuery(CommandType commandType, string query, IEnumerable<SqlParameter> parameters, Func<Task<SqlConnection>> sqlConnection)
		{
			SetEmptyOrNullParametersToDBNull(parameters);

			using (var conn = await sqlConnection())
			{
				using (var cmd = new SqlCommand(query, conn))
				{
					cmd.CommandType = commandType;
					cmd.Parameters.AddRange(parameters.ToArray());
					await conn.OpenAsync();
					//try
					//{
						await cmd.ExecuteNonQueryAsync();
					//}
					//catch (SqlException se)
					//{
					//	throw new Exception(se.Message);
					//	//HandleException(se, query, parameters);
					//}
				}
			}
		}

		private void SetEmptyOrNullParametersToDBNull(IEnumerable<SqlParameter> parameters)
		{
			// TODO: Refactor it to return a new array, should not modify the input
			foreach (var parameter in parameters)
			{
				if (parameter.SqlDbType != SqlDbType.Structured)
				{
					if (parameter.SqlValue == null)
						parameter.SqlValue = DBNull.Value;
					else
					{
						bool isStringAndEmpty = parameter.SqlValue.GetType().Equals(typeof(SqlString)) && string.IsNullOrWhiteSpace(parameter.SqlValue.ToString());
						if (isStringAndEmpty)
							parameter.SqlValue = DBNull.Value;
					}
				}
			}
		}
	}
}
