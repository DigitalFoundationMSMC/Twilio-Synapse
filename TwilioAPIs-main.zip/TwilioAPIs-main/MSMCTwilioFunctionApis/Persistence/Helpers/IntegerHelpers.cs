﻿using System;

namespace MSMCTwilioFunctionApis.Persistence.Helpers
{
    public static class IntegerHelpers
    {
        public static int? ParseFromDatabase(object input)
        {
            return input is DBNull ? null : (int?)Convert.ToInt32(input);
        }

        public static object StoreNullableInDatabase(int? input)
        {
            return input.HasValue ? (object)input.Value : DBNull.Value;
        }
    }
}
