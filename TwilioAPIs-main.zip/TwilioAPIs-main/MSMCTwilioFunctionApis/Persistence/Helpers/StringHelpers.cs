﻿using System;

namespace MSMCTwilioFunctionApis.Persistence.Helpers
{
    public static class StringHelpers
    {
        public static string ParseFromDatabase(object input)
        {
            return input is DBNull ? null : Convert.ToString(input);
        }

        public static object StoreNullableInDatabase(string input)
        {
            return string.IsNullOrWhiteSpace(input) ? DBNull.Value : (object)input;
        }
    }
}
