﻿using MSMCTwilioFunctionApis.Auth;
using MSMCTwilioFunctionApis.Common.DTO;
using MSMCTwilioFunctionApis.Persistence.Helpers;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace MSMCTwilioFunctionApis.Persistence.Repositories
{
	public interface ITwilioFunctionRepository
	{
		Task SaveDummyResponsesToTwilio(string toPhoneNumber, string body, DateTime? dateSent, string direction);
		Task SaveFunctionParamsLost(string pid, string csn, string call, DateTime createdAt, string toPhoneNumber, string flowId, string executionId, string sid);
		Task SaveFunctionParams(TwilioFunctionParamsDTO dto);
		Task SaveFunctionParamsTST(TwilioFunctionParamsDTO dto);
		Task SaveShortCodeMessageDetails(SendShortCodeDTO dto);
		Task<SendShortCodeDTO> RespondToShortCode(SendShortCodeDTO dto);
		Task SaveExecutionData(ExecutionDTO dto);
		Task SaveTwilioResponse(TwilioResponseDTO dto);
		Task<bool> IsPatientSubscriptionExist(string phoneNumber);
		Task SavePatientSubscription(PatientSubscriptionDTO dto);
		Task<IEnumerable<TwilioFunctionParamsDTO>> GetAll();
		Task<SendShortCodeDTO> GetExecutionDetailsByPhoneNumber(string phoneNumber);
		Task UpdatePatientSubscription(PatientSubscriptionDTO dto);
		Task<bool> IsValidUser(string userName, string password);
	}

	public class TwilioFunctionRepository : ITwilioFunctionRepository
	{
		private readonly IDbService _dbService;
		private readonly IAuthService _authService;

		public TwilioFunctionRepository(IDbService dbService, IAuthService authService)
		{
			_dbService = dbService ?? throw new ArgumentNullException(nameof(dbService));
			_authService = authService ?? throw new ArgumentNullException(nameof(authService));
		}

		public async Task SaveDummyResponsesToTwilio(string toPhoneNumber, string body, DateTime? dateSent, string direction)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter("toPhoneNumber", toPhoneNumber));
			parameters.Add(new SqlParameter("body", body));
			parameters.Add(new SqlParameter("dateSent", dateSent));
			parameters.Add(new SqlParameter("direction", direction));
			var query = @"INSERT INTO DummyResponsesGetByTwilio(toPhoneNumber, body, dateSent, direction)values
						(@toPhoneNumber, @body, @dateSent, @direction)";

			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task SaveFunctionParams(TwilioFunctionParamsDTO dto)
		{
			var parameters = GetParameters(dto);
			var query = GetQuery("TwilIoConfirmations");
			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task SaveFunctionParamsLost(string pid, string csn, string call, DateTime createdAt, string toPhoneNumber, string flowId,
			string executionId, string sid)
		{
			TwilioFunctionParamsDTO dto = new TwilioFunctionParamsDTO();
			dto.Pid = pid;
			dto.Csn = csn;
			dto.Call = call;
			dto.Sms = "1";
			dto.Type = "Text message";
			var parameters = GetParameters(dto, false);
			parameters.Add(new SqlParameter(TwilioFunctionColumns.CreatedAt, createdAt));
			parameters.Add(new SqlParameter("toPhoneNumber", toPhoneNumber));
			parameters.Add(new SqlParameter("flowId", flowId));
			parameters.Add(new SqlParameter("executionId", executionId));
			parameters.Add(new SqlParameter("sid", sid));
			var query = $@"INSERT INTO TwilIoConfirmationsLost({TwilioFunctionColumns.Csn}, {TwilioFunctionColumns.Pid}, {TwilioFunctionColumns.Call},
						{TwilioFunctionColumns.Confirmed}, {TwilioFunctionColumns.Sms}, {TwilioFunctionColumns.Type}, {TwilioFunctionColumns.IsCopied},
						{TwilioFunctionColumns.CreatedAt}, toPhoneNumber, flowId, executionId, sid)
						VALUES(@{TwilioFunctionColumns.Csn} ,@{TwilioFunctionColumns.Pid}, @{TwilioFunctionColumns.Call},
						@{TwilioFunctionColumns.Confirmed}, @{TwilioFunctionColumns.Sms}, @{TwilioFunctionColumns.Type}, @{TwilioFunctionColumns.IsCopied},
						@{TwilioFunctionColumns.CreatedAt}, @toPhoneNumber, @flowId, @executionId, @sid)"; ;
			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task SaveFunctionParamsTST(TwilioFunctionParamsDTO dto)
		{
			var parameters = GetParameters(dto);
			var query = GetQuery("TwilIoConfirmationsTST");
			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task<SendShortCodeDTO> RespondToShortCode(SendShortCodeDTO dto)
		{
			var result = await GetExecutionDetailsByPhoneNumber(dto.ToPhoneNumber);

			if (string.IsNullOrEmpty(result.FlowId))
				throw new Exception("No execution data exist against the patient with phone number " + dto.ToPhoneNumber);

			var updateParameters = new List<SqlParameter>();
			updateParameters.Add(new SqlParameter(ShortCodeColumns.ToPhoneNumber, dto.ToPhoneNumber));
			updateParameters.Add(new SqlParameter(ShortCodeColumns.PatientResponse, dto.PatientResponse));
			updateParameters.Add(new SqlParameter(ShortCodeColumns.Id, result.Id));

			var query = $@"UPDATE ShortCodeMessage SET {ShortCodeColumns.HasResponded} = -1
						WHERE {ShortCodeColumns.ToPhoneNumber} = @{ShortCodeColumns.ToPhoneNumber}
						AND {ShortCodeColumns.HasResponded} = 0

						UPDATE ShortCodeMessage SET {ShortCodeColumns.HasResponded} = 1, {ShortCodeColumns.PatientResponse} = @{ShortCodeColumns.PatientResponse}
						WHERE {ShortCodeColumns.Id} = @{ShortCodeColumns.Id} ";
			await _dbService.Execute(CommandType.Text, query, updateParameters);

			return result;
		}

		public async Task SaveShortCodeMessageDetails(SendShortCodeDTO dto)
		{
			var query = $@"INSERT INTO ShortCodeMessage(
							{ShortCodeColumns.ExecutionId}, {ShortCodeColumns.FlowId}, {ShortCodeColumns.ToPhoneNumber},
							{ShortCodeColumns.PatientResponse}, {ShortCodeColumns.Body}, {ShortCodeColumns.CreatedAt},
							{ShortCodeColumns.HasResponded}, {ShortCodeColumns.IsDelivered},
							{ShortCodeColumns.Language})
							VALUES(
							@{ShortCodeColumns.ExecutionId}, @{ShortCodeColumns.FlowId}, @{ShortCodeColumns.ToPhoneNumber},
							@{ShortCodeColumns.PatientResponse}, @{ShortCodeColumns.Body}, @{ShortCodeColumns.CreatedAt},
							@{ShortCodeColumns.HasResponded}, @{ShortCodeColumns.IsDelivered},
							@{ShortCodeColumns.Language})";

			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(ShortCodeColumns.ExecutionId, dto.ExecutionId));
			parameters.Add(new SqlParameter(ShortCodeColumns.FlowId, dto.FlowId));
			parameters.Add(new SqlParameter(ShortCodeColumns.ToPhoneNumber, dto.ToPhoneNumber));
			parameters.Add(new SqlParameter(ShortCodeColumns.PatientResponse, dto.PatientResponse));
			parameters.Add(new SqlParameter(ShortCodeColumns.Body, dto.Body));
			parameters.Add(new SqlParameter(ShortCodeColumns.CreatedAt, DateTime.Now));
			parameters.Add(new SqlParameter(ShortCodeColumns.HasResponded, dto.HasResponded));
			parameters.Add(new SqlParameter(ShortCodeColumns.IsDelivered, dto.IsDelivered));

			if (!string.IsNullOrEmpty(dto.Language))
				parameters.Add(new SqlParameter(ShortCodeColumns.Language, dto.Language));
			else
				parameters.Add(new SqlParameter(ShortCodeColumns.Language, "22"));

			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task SaveExecutionData(ExecutionDTO dto)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Pid_16, dto.Pid_16));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Time_5, dto.Time_5));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Visit_7, dto.Visit_7));
			bool? dose_29 = null;

			if (dto.Dose_29 == "1")
				dose_29 = true;
			else if (dto.Dose_29 == "0")
				dose_29 = false;

			parameters.Add(new SqlParameter(TwilioRequestsColumns.Dose_29, dose_29));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Confirmed_24, dto.Confirmed_24));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Lname_18, dto.Lname_18));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.DayOfWeek_6, dto.DayOfWeek_6));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Csn_2, dto.Csn_2));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Fname_19, dto.Fname_19));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Depphone_27, dto.Depphone_27));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Date_4, dto.Date_4));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Multiple_12, dto.Multiple_12));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Department_14, dto.Department_14));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Preferred_20, dto.Preferred_20));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Depid_26, dto.Depid_26));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Provider_15, dto.Provider_15));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Language_22, dto.Language_22));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Commid_23, dto.Commid_23));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Arrival, dto.Arrival));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Status_30, dto.Status_30));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Cell_21, dto.Cell_21));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Vid_25, dto.Vid_25));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.PatResponse, dto.PatResponse));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Daynum, dto.Daynum));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.Filetype, dto.Filetype));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.PhoneNumber, dto.PhoneNumber));
			parameters.Add(new SqlParameter(TwilioRequestsColumns.CreatedAt, DateTime.Now));

			var query = $@"INSERT INTO TwilioRequests(
							{TwilioRequestsColumns.Pid_16}, {TwilioRequestsColumns.Time_5},
							{TwilioRequestsColumns.Visit_7}, {TwilioRequestsColumns.Dose_29},
							{TwilioRequestsColumns.Confirmed_24}, {TwilioRequestsColumns.Lname_18},
							{TwilioRequestsColumns.DayOfWeek_6}, {TwilioRequestsColumns.Csn_2},
							{TwilioRequestsColumns.Fname_19}, {TwilioRequestsColumns.Depphone_27},
							{TwilioRequestsColumns.Date_4}, {TwilioRequestsColumns.Multiple_12},
							{TwilioRequestsColumns.Department_14}, {TwilioRequestsColumns.Preferred_20},
							{TwilioRequestsColumns.Depid_26}, {TwilioRequestsColumns.Provider_15},
							{TwilioRequestsColumns.Language_22}, {TwilioRequestsColumns.Commid_23},
							{TwilioRequestsColumns.Arrival}, {TwilioRequestsColumns.Status_30},
							{TwilioRequestsColumns.Cell_21}, {TwilioRequestsColumns.Vid_25},
							{TwilioRequestsColumns.PatResponse}, {TwilioRequestsColumns.Daynum},
							{TwilioRequestsColumns.Filetype}, {TwilioRequestsColumns.PhoneNumber},
							{TwilioRequestsColumns.CreatedAt}) 
							VALUES(
							@{TwilioRequestsColumns.Pid_16}, @{TwilioRequestsColumns.Time_5},
							@{TwilioRequestsColumns.Visit_7}, @{TwilioRequestsColumns.Dose_29},
							@{TwilioRequestsColumns.Confirmed_24}, @{TwilioRequestsColumns.Lname_18},
							@{TwilioRequestsColumns.DayOfWeek_6}, @{TwilioRequestsColumns.Csn_2},
							@{TwilioRequestsColumns.Fname_19}, @{TwilioRequestsColumns.Depphone_27},
							@{TwilioRequestsColumns.Date_4}, @{TwilioRequestsColumns.Multiple_12},
							@{TwilioRequestsColumns.Department_14}, @{TwilioRequestsColumns.Preferred_20},
							@{TwilioRequestsColumns.Depid_26}, @{TwilioRequestsColumns.Provider_15},
							@{TwilioRequestsColumns.Language_22}, @{TwilioRequestsColumns.Commid_23},
							@{TwilioRequestsColumns.Arrival}, @{TwilioRequestsColumns.Status_30},
							@{TwilioRequestsColumns.Cell_21}, @{TwilioRequestsColumns.Vid_25},
							@{TwilioRequestsColumns.PatResponse}, @{TwilioRequestsColumns.Daynum},
							@{TwilioRequestsColumns.Filetype}, @{TwilioRequestsColumns.PhoneNumber},
							@{TwilioRequestsColumns.CreatedAt})";

			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task SaveTwilioResponse(TwilioResponseDTO dto)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(TwilioResponseColumns.Body, dto.Body.Trim()));
			parameters.Add(new SqlParameter(TwilioResponseColumns.PhoneNumber, dto.PhoneNumber));
			parameters.Add(new SqlParameter(TwilioResponseColumns.CreatedAt, DateTime.Now));

			var query = $@"INSERT INTO TwilioResponse({TwilioResponseColumns.Body}, {TwilioResponseColumns.CreatedAt},
							{TwilioResponseColumns.PhoneNumber})VALUES
							(@{TwilioResponseColumns.Body}, @{TwilioResponseColumns.CreatedAt},
							@{TwilioResponseColumns.PhoneNumber})";

			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task<bool> IsPatientSubscriptionExist(string phoneNumber)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.PhoneNumber, phoneNumber));

			var query = $@"SELECT PhoneNumber FROM PatientSubscription 
							WHERE {PatientSubscriptionColumns.PhoneNumber} = @{PatientSubscriptionColumns.PhoneNumber}
							AND {PatientSubscriptionColumns.IsCopied} = 0";

			return await _dbService.Query(CommandType.Text, query, parameters, dr =>
			{
				var result = false;

				if (dr.Read())
					result = true;

				return result;
			});
		}

		public async Task SavePatientSubscription(PatientSubscriptionDTO dto)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.PhoneNumber, dto.PhoneNumber));
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.SubscriptionType, dto.SubscriptionType));
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.CreatedAt, DateTime.Now));

			var query = $@"INSERT INTO PatientSubscription({PatientSubscriptionColumns.PhoneNumber}, {PatientSubscriptionColumns.SubscriptionType},
							{PatientSubscriptionColumns.CreatedAt})VALUES
							(@{PatientSubscriptionColumns.PhoneNumber}, @{PatientSubscriptionColumns.SubscriptionType},
							@{PatientSubscriptionColumns.CreatedAt})";

			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task<IEnumerable<TwilioFunctionParamsDTO>> GetAll()
		{
			var query = $@"SELECT * FROM TwilIoConfirmations";

			return await _dbService.Query(CommandType.Text, query, new List<SqlParameter>(), dr =>
			{
				var result = new List<TwilioFunctionParamsDTO>();

				while (dr.Read())
				{
					var record = new TwilioFunctionParamsDTO();
					record.Id = IntegerHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Id]) ?? 0;
					record.Csn = StringHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Csn]);
					record.Pid = StringHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Pid]);
					record.Call = StringHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Call]);
					record.Confirmed = StringHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Confirmed]);
					record.Sms = StringHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Sms]);
					record.Type = StringHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.Type]);
					record.IsCopied = BooleanHelpers.ParseFromDatabase(dr[TwilioFunctionColumns.IsCopied]) ?? false;

					result.Add(record);
				}

				return result;
			});
		}

		public async Task<SendShortCodeDTO> GetExecutionDetailsByPhoneNumber(string phoneNumber)
		{
			var getParameters = new List<SqlParameter>();
			getParameters.Add(new SqlParameter(ShortCodeColumns.ToPhoneNumber, phoneNumber));
			var query = $@"SELECT TOP(1) {ShortCodeColumns.Id}, {ShortCodeColumns.ExecutionId}, {ShortCodeColumns.FlowId}, {ShortCodeColumns.ToPhoneNumber},
										 {ShortCodeColumns.PatientResponse}, {ShortCodeColumns.Body}, {ShortCodeColumns.CreatedAt}, {ShortCodeColumns.Language}
										 FROM ShortCodeMessage 
										 WHERE {ShortCodeColumns.ToPhoneNumber} = @{ShortCodeColumns.ToPhoneNumber} AND {ShortCodeColumns.HasResponded} = 0
										 ORDER BY {ShortCodeColumns.CreatedAt} DESC";


			return await _dbService.Query(CommandType.Text, query, getParameters, dr =>
			{
				var result = new SendShortCodeDTO();

				if (dr.Read())
				{
					result.Id = IntegerHelpers.ParseFromDatabase(dr[ShortCodeColumns.Id]) ?? 0;
					result.ExecutionId = StringHelpers.ParseFromDatabase(dr[ShortCodeColumns.ExecutionId]);
					result.FlowId = StringHelpers.ParseFromDatabase(dr[ShortCodeColumns.FlowId]);
					result.ToPhoneNumber = StringHelpers.ParseFromDatabase(dr[ShortCodeColumns.ToPhoneNumber]);
					result.PatientResponse = StringHelpers.ParseFromDatabase(dr[ShortCodeColumns.PatientResponse]);
					result.Body = StringHelpers.ParseFromDatabase(dr[ShortCodeColumns.Body]);
					result.CreatedAt = DateTimeHelpers.ParseFromDatabase(dr[ShortCodeColumns.CreatedAt]);
					result.Language = StringHelpers.ParseFromDatabase(dr[ShortCodeColumns.Language]);
				}

				return result;
			});
		}

		public async Task UpdatePatientSubscription(PatientSubscriptionDTO dto)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.PhoneNumber, dto.PhoneNumber));
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.SubscriptionType, dto.SubscriptionType));
			parameters.Add(new SqlParameter(PatientSubscriptionColumns.CreatedAt, DateTime.Now));

			var query = $@"UPDATE PatientSubscription SET 
								  {PatientSubscriptionColumns.SubscriptionType} = @{PatientSubscriptionColumns.SubscriptionType},
								  {PatientSubscriptionColumns.CreatedAt} = @{PatientSubscriptionColumns.CreatedAt}
								  WHERE {PatientSubscriptionColumns.PhoneNumber} = @{PatientSubscriptionColumns.PhoneNumber}
								  AND {PatientSubscriptionColumns.IsCopied} = 0";

			await _dbService.Execute(CommandType.Text, query, parameters);
		}

		public async Task<bool> IsValidUser(string userName, string password)
		{
			var query = "SELECT * FROM [User] WHERE username like @username AND password like @password";
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter("username", userName));
			parameters.Add(new SqlParameter("password", password));

			return await _dbService.Query(CommandType.Text, query, parameters, dr =>
			{
				if (dr.Read())
					return true;

				return false;
			});
		}

		private string GetQuery(string tableName)
		{
			return $@"INSERT INTO {tableName}({TwilioFunctionColumns.Csn}, {TwilioFunctionColumns.Pid}, {TwilioFunctionColumns.Call},
						{TwilioFunctionColumns.Confirmed}, {TwilioFunctionColumns.Sms}, {TwilioFunctionColumns.Type}, {TwilioFunctionColumns.IsCopied},
						{TwilioFunctionColumns.CreatedAt})
						VALUES(@{TwilioFunctionColumns.Csn} ,@{TwilioFunctionColumns.Pid}, @{TwilioFunctionColumns.Call},
						@{TwilioFunctionColumns.Confirmed}, @{TwilioFunctionColumns.Sms}, @{TwilioFunctionColumns.Type}, @{TwilioFunctionColumns.IsCopied},
						@{TwilioFunctionColumns.CreatedAt})";
		}

		private IList<SqlParameter> GetParameters(TwilioFunctionParamsDTO dto, bool addCreatedAtField = true)
		{
			var parameters = new List<SqlParameter>();
			parameters.Add(new SqlParameter(TwilioFunctionColumns.Csn, dto.Csn));
			parameters.Add(new SqlParameter(TwilioFunctionColumns.Pid, dto.Pid));
			parameters.Add(new SqlParameter(TwilioFunctionColumns.Call, dto.Call));
			parameters.Add(new SqlParameter(TwilioFunctionColumns.Confirmed, dto.Confirmed));
			parameters.Add(new SqlParameter(TwilioFunctionColumns.Sms, dto.Sms));
			parameters.Add(new SqlParameter(TwilioFunctionColumns.Type, dto.Type));
			parameters.Add(new SqlParameter(TwilioFunctionColumns.IsCopied, false));

			if (addCreatedAtField)
				parameters.Add(new SqlParameter(TwilioFunctionColumns.CreatedAt, DateTime.Now));

			return parameters;
		}

		private static class TwilioFunctionColumns
		{
			public static string Id = "id";
			public static string Csn = "csn";
			public static string Pid = "pid";
			public static string Call = "call";
			public static string Confirmed = "confirmed";
			public static string Sms = "sms";
			public static string Type = "type";
			public static string IsCopied = "iscopied";
			public static string CreatedAt = "createdat";
		}

		private static class ShortCodeColumns
		{
			public static string Id = "id";
			public static string ExecutionId = "executionid";
			public static string FlowId = "flowid";
			public static string ToPhoneNumber = "tophonenumber";
			public static string PatientResponse = "patientresponse";
			public static string Body = "body";
			public static string CreatedAt = "createdat";
			public static string HasResponded = "hasresponded";
			public static string IsDelivered = "isdelivered";
			public static string Language = "language";
		}

		private static class TwilioRequestsColumns
		{
			public static string Id = "id";
			public static string Pid_16 = "pid_16";
			public static string Time_5 = "time_5";
			public static string Visit_7 = "visit_7";
			public static string Dose_29 = "dose_29";
			public static string Confirmed_24 = "confirmed_24";
			public static string Lname_18 = "lname_18";
			public static string DayOfWeek_6 = "dayofweek_6";
			public static string Csn_2 = "csn_2";
			public static string Fname_19 = "fname_19";
			public static string Depphone_27 = "depphone_27";
			public static string Date_4 = "date_4";
			public static string Multiple_12 = "multiple_12";
			public static string Department_14 = "department_14";
			public static string Preferred_20 = "preferred_20";
			public static string Depid_26 = "depid_26";
			public static string Provider_15 = "provider_15";
			public static string Language_22 = "language_22";
			public static string Commid_23 = "commid_23";
			public static string Arrival = "arrival";
			public static string Status_30 = "status_30";
			public static string Cell_21 = "cell_21";
			public static string Vid_25 = "vid_25";
			public static string PatResponse = "patresponse";
			public static string Daynum = "daynum";
			public static string Filetype = "filetype";
			public static string PhoneNumber = "phonenumber";
			public static string CreatedAt = "createdat";

		}

		private static class TwilioResponseColumns
		{
			public static string Id = "id";
			public static string Body = "Body";
			public static string PhoneNumber = "PhoneNumber";
			public static string CreatedAt = "CreatedAt";
		}

		private static class PatientSubscriptionColumns
		{
			public static string Id = "id";
			public static string PhoneNumber = "PhoneNumber";
			public static string SubscriptionType = "SubscriptionType";
			public static string CreatedAt = "CreatedAt";
			public static string IsCopied = "iscopied";
		}
	}
}
